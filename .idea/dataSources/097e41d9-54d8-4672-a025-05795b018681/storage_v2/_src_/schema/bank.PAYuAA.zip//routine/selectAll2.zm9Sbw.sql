CREATE PROCEDURE selectAll2(IN name_1 VARCHAR(255))
  BEGIN
    DECLARE a VARCHAR(255);
    SET a = name_1;
    SELECT *
    FROM client
    WHERE FirstName = a;
  END;

